// src/main.js
export class Game {
  constructor({ THREE, CANNON, container, scoreEl, nextEl }) {
    this.THREE = THREE; this.CANNON = CANNON;
    this.container = container; this.scoreEl = scoreEl; this.nextEl = nextEl;
    this.init();
  }

  init() {
    const { THREE } = this;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0e0e10);

    this.camera = new THREE.PerspectiveCamera(55, this.container.clientWidth / this.container.clientHeight, 0.1, 200);
    this.camera.position.set(0, 7.5, 13);

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
    this.container.appendChild(this.renderer.domElement);

    // Lights
    const hemi = new THREE.HemisphereLight(0xffffff, 0x404040, 0.9);
    this.scene.add(hemi);
    const dir = new THREE.DirectionalLight(0xffffff, 0.8);
    dir.position.set(5, 10, 7);
    this.scene.add(dir);

    // Cannon world
    const CANNON = this.CANNON;
    this.world = new CANNON.World({ gravity: new CANNON.Vec3(0, -9.82, 0) });
    this.world.broadphase = new CANNON.NaiveBroadphase();
    this.world.solver.iterations = 10;

    // Container: floor + cylinder walls
    this.createArena();

    // Fruit types (simplified, colored spheres)
    // size increases ~1.25x each level
    this.fruits = [
      { name: 'Grape', radius: 0.40, color: 0x7a1fa2, score: 1 },
      { name: 'Cherry', radius: 0.50, color: 0xe11d48, score: 2 },
      { name: 'Strawberry', radius: 0.62, color: 0xff3b30, score: 4 },
      { name: 'Orange', radius: 0.78, color: 0xff9500, score: 8 },
      { name: 'Apple', radius: 0.98, color: 0x34c759, score: 16 },
      { name: 'Pear', radius: 1.22, color: 0x9acd32, score: 24 },
      { name: 'Peach', radius: 1.52, color: 0xffc07a, score: 32 },
      { name: 'Pineapple', radius: 1.90, color: 0xfad02e, score: 48 },
      { name: 'Melon', radius: 2.40, color: 0x2dd4bf, score: 64 },
      { name: 'Watermelon', radius: 3.00, color: 0x16a34a, score: 128 }
    ];

    this.objects = []; // { mesh, body, type }
    this.score = 0;

    // Spawner
    this.spawnerX = 0;
    this.nextType = this.randomTypeIndex(0, 5); // early-game smalls
    this.updateNextLabel();

    // Input
    this.keys = { left: false, right: false, drop: false };
    window.addEventListener('keydown', (e)=>this.onKey(e, true));
    window.addEventListener('keyup', (e)=>this.onKey(e, false));
    window.addEventListener('resize', () => this.onResize());

    this.lastTime = performance.now();
    this.loop();
  }

  restart() {
    // remove meshes & bodies
    this.objects.forEach(o => {
      this.scene.remove(o.mesh);
      this.world.removeBody(o.body);
    });
    this.objects = [];
    this.score = 0;
    this.scoreEl.textContent = this.score.toString();
    this.nextType = this.randomTypeIndex(0, 5);
    this.updateNextLabel();
  }

  onKey(e, down) {
    if (e.code === 'ArrowLeft' || e.code === 'KeyA') this.keys.left = down;
    if (e.code === 'ArrowRight' || e.code === 'KeyD') this.keys.right = down;
    if (e.code === 'Space') { if (down) this.dropFruit(); e.preventDefault(); }
  }

  onResize() {
    const w = this.container.clientWidth, h = this.container.clientHeight;
    this.camera.aspect = w/h; this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  createArena() {
    const { THREE, CANNON } = this;

    // Visual floor
    const floorGeom = new THREE.CircleGeometry(6.0, 64);
    const floorMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, metalness: 0.2, roughness: 0.8 });
    const floor = new THREE.Mesh(floorGeom, floorMat);
    floor.rotation.x = -Math.PI/2;
    floor.position.y = 0;
    floor.receiveShadow = true;
    this.scene.add(floor);

    // Rim (visual walls)
    const rimGeom = new THREE.CylinderGeometry(6.1, 6.1, 5.5, 64, 1, true);
    const rimMat = new THREE.MeshStandardMaterial({ color: 0x0b1220, metalness: 0.1, roughness: 0.9, side: THREE.DoubleSide, transparent: true, opacity: 0.9 });
    const rim = new THREE.Mesh(rimGeom, rimMat);
    rim.position.y = 2.75;
    this.scene.add(rim);

    // Physics: floor
    const groundBody = new CANNON.Body({ type: CANNON.Body.STATIC });
    groundBody.addShape(new CANNON.Plane());
    groundBody.quaternion.setFromEuler(-Math.PI/2, 0, 0);
    groundBody.position.set(0, 0, 0);
    this.world.addBody(groundBody);

    // Physics: cylindrical wall as many vertical planes approximating a circle
    const segments = 24;
    const radius = 6.0;
    for (let i=0;i<segments;i++) {
      const angle = (i/segments) * Math.PI * 2;
      const nx = Math.cos(angle), nz = Math.sin(angle);
      const plane = new CANNON.Body({ type: CANNON.Body.STATIC });
      plane.addShape(new CANNON.Plane());
      // position: push plane outward so its inside face forms the circle
      plane.position.set(nx*radius, 2.5, nz*radius);
      // rotate so plane normal points inward
      const q = new CANNON.Quaternion();
      q.setFromEuler(0, angle + Math.PI, 0);
      plane.quaternion.copy(q);
      this.world.addBody(plane);
    }
  }

  randomTypeIndex(minInc=0, maxInc=null) {
    if (maxInc===null) maxInc = this.fruits.length-2; // avoid spawning the final fruit
    return Math.floor(Math.random() * (maxInc - minInc + 1)) + minInc;
  }

  updateNextLabel() {
    this.nextEl.textContent = this.fruits[this.nextType].name;
  }

  spawnFruit(typeIdx, x=0, y=8, z=0) {
    const { THREE, CANNON } = this;
    const f = this.fruits[typeIdx];
    const geom = new THREE.SphereGeometry(f.radius, 24, 18);
    const mat = new THREE.MeshStandardMaterial({ color: f.color, metalness: 0.1, roughness: 0.6 });
    const mesh = new THREE.Mesh(geom, mat);
    mesh.castShadow = true; mesh.receiveShadow = true;
    mesh.position.set(x, y, z);
    this.scene.add(mesh);

    const body = new CANNON.Body({
      mass: Math.pow(f.radius, 3) * 0.5, // rough mass scaling
      shape: new CANNON.Sphere(f.radius),
      material: new CANNON.Material('fruit')
    });
    body.position.set(x, y, z);
    body.linearDamping = 0.01;
    body.angularDamping = 0.01;
    body.userData = { typeIdx };
    this.world.addBody(body);

    const obj = { mesh, body, type: typeIdx, mergedRecently: false };
    this.objects.push(obj);
    return obj;
  }

  dropFruit() {
    // constrain x within rim
    const x = Math.max(-4.8, Math.min(4.8, this.spawnerX));
    this.spawnFruit(this.nextType, x, 10, 0);
    this.nextType = this.randomTypeIndex();
    this.updateNextLabel();
  }

  attemptMerge(a, b) {
    if (a.mergedRecently || b.mergedRecently) return false;
    if (a.type !== b.type) return false;
    if (a.type >= this.fruits.length - 1) return false; // can't upgrade further
    // Must be slow & close
    const dv = a.body.velocity.length() + b.body.velocity.length();
    if (dv > 1.5) return false;
    const d = a.body.position.vsub(b.body.position).length();
    const r = this.fruits[a.type].radius * 2.0;
    if (d > r * 0.9) return false;

    // Merge: remove both and spawn next at midpoint
    const nextType = a.type + 1;
    const mid = a.body.position.vadd(b.body.position).scale(0.5);
    this.removeObject(a);
    this.removeObject(b);
    const merged = this.spawnFruit(nextType, mid.x, mid.y + 0.05, mid.z);

    // small "pop" upward impulse
    merged.body.applyImpulse(new this.CANNON.Vec3(0, 2.5, 0), merged.body.position);

    // score
    const pts = this.fruits[nextType].score;
    this.score += pts;
    this.scoreEl.textContent = this.score.toString();

    // prevent chain immediate re-merge
    merged.mergedRecently = true;
    setTimeout(() => merged.mergedRecently = false, 300);
    return true;
  }

  removeObject(obj) {
    const i = this.objects.indexOf(obj);
    if (i >= 0) this.objects.splice(i,1);
    this.scene.remove(obj.mesh);
    this.world.removeBody(obj.body);
  }

  loop() {
    requestAnimationFrame(()=>this.loop());
    const now = performance.now();
    const dt = Math.min(1/30, (now - this.lastTime) / 1000);
    this.lastTime = now;

    // Spawner movement
    const speed = 6.0;
    if (this.keys.left) this.spawnerX -= speed*dt;
    if (this.keys.right) this.spawnerX += speed*dt;
    this.spawnerX = Math.max(-5.0, Math.min(5.0, this.spawnerX));

    // Physics step
    this.world.step(1/60, dt, 3);

    // Sync meshes & track possible merges
    for (const obj of this.objects) {
      obj.mesh.position.copy(obj.body.position);
      obj.mesh.quaternion.copy(obj.body.quaternion);
    }

    // Naive O(n^2) merge check for small counts
    const n = this.objects.length;
    for (let i=0;i<n;i++) {
      for (let j=i+1;j<n;j++) {
        this.attemptMerge(this.objects[i], this.objects[j]);
      }
    }

    // Simple lose condition: if any fruit rises above wall height for too long
    const over = this.objects.some(o => o.body.position.y > 5.6);
    if (over) {
      // fade background to warn
      this.scene.background.setHex(0x220c10);
    } else {
      this.scene.background.setHex(0x0e0e10);
    }

    // Render
    this.renderer.render(this.scene, this.camera);

    // Draw spawner as a subtle hovering ring
    this.drawSpawnerGizmo();
  }

  drawSpawnerGizmo() {
    if (!this._gizmo) {
      const g = new this.THREE.Group();
      const torus = new this.THREE.Mesh(
        new this.THREE.TorusGeometry(0.5, 0.05, 8, 24),
        new this.THREE.MeshBasicMaterial({ color: 0x93c5fd })
      );
      torus.rotation.x = Math.PI/2;
      g.add(torus);
      this.scene.add(g);
      this._gizmo = g;
    }
    this._gizmo.position.set(this.spawnerX, 9.5, 0);
  }
}
